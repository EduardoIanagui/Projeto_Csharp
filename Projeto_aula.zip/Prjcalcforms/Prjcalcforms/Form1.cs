﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prjcalcforms
{
    public partial class formscalc : Form
    {
        public formscalc()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            if (rdosoma.Checked == true)
            {
                double n1, n2, r;
                n1 = Convert.ToDouble(txtn1.Text);
                n2 = Convert.ToDouble(txtn2.Text);
                r = n1 + n2;
                lblresult.Text = "A soma é: " + r;
            }
            else if (rdosubt.Checked == true)
            {
                double n1, n2, r;
                n1 = Convert.ToDouble(txtn1.Text);
                n2 = Convert.ToDouble(txtn2.Text);
                r = n1 - n2;
                lblresult.Text = "A subtração é: " + r;
            }
            else if (rdomultip.Checked == true)
            {
                double n1, n2, r;
                n1 = Convert.ToDouble(txtn1.Text);
                n2 = Convert.ToDouble(txtn2.Text);
                r = n1 * n2;
                lblresult.Text = "A multiplicação é: " + r;
            }
            else if (rdodivis.Checked == true)
            {
                double n1, n2, r;
                n1 = Convert.ToDouble(txtn1.Text);
                n2 = Convert.ToDouble(txtn2.Text);
                r =Math.Round( n1 / n2, 4);                
                lblresult.Text = "A divisão é: " + r;
            }
            else
            {
                lblresult.Text = "escolha uma opção antes de iniciar a operação";
            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtn1.Clear();
            txtn2.Clear();
            lblresult.Text = "Resultado: ...";
            rdosoma.Checked = false;
            rdosubt.Checked = false;
            rdodivis.Checked = false;
            rdomultip.Checked = false;
            txtn1.Focus();
        }
    }
}
