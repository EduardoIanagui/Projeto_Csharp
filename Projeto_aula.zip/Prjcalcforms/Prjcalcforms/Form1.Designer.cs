﻿namespace Prjcalcforms
{
    partial class formscalc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.lbln1 = new System.Windows.Forms.Label();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lblresult = new System.Windows.Forms.Label();
            this.btncalc = new System.Windows.Forms.Button();
            this.rdosoma = new System.Windows.Forms.RadioButton();
            this.rdosubt = new System.Windows.Forms.RadioButton();
            this.rdodivis = new System.Windows.Forms.RadioButton();
            this.rdomultip = new System.Windows.Forms.RadioButton();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtn1
            // 
            this.txtn1.Location = new System.Drawing.Point(372, 108);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(100, 20);
            this.txtn1.TabIndex = 4;
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(372, 171);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(100, 20);
            this.txtn2.TabIndex = 5;
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Location = new System.Drawing.Point(245, 111);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(100, 13);
            this.lbln1.TabIndex = 6;
            this.lbln1.Text = "Informe um número:";
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Location = new System.Drawing.Point(245, 174);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(100, 13);
            this.lbln2.TabIndex = 7;
            this.lbln2.Text = "Informe um número:";
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblresult.Location = new System.Drawing.Point(372, 306);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(72, 15);
            this.lblresult.TabIndex = 8;
            this.lblresult.Text = "Resultado: ...";
            this.lblresult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(65, 370);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(75, 23);
            this.btncalc.TabIndex = 9;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // rdosoma
            // 
            this.rdosoma.AutoSize = true;
            this.rdosoma.Location = new System.Drawing.Point(611, 81);
            this.rdosoma.Name = "rdosoma";
            this.rdosoma.Size = new System.Drawing.Size(50, 17);
            this.rdosoma.TabIndex = 10;
            this.rdosoma.TabStop = true;
            this.rdosoma.Text = "soma";
            this.rdosoma.UseVisualStyleBackColor = true;
            // 
            // rdosubt
            // 
            this.rdosubt.AutoSize = true;
            this.rdosubt.Location = new System.Drawing.Point(611, 134);
            this.rdosubt.Name = "rdosubt";
            this.rdosubt.Size = new System.Drawing.Size(72, 17);
            this.rdosubt.TabIndex = 11;
            this.rdosubt.TabStop = true;
            this.rdosubt.Text = "subtração";
            this.rdosubt.UseVisualStyleBackColor = true;
            // 
            // rdodivis
            // 
            this.rdodivis.AutoSize = true;
            this.rdodivis.Location = new System.Drawing.Point(611, 191);
            this.rdodivis.Name = "rdodivis";
            this.rdodivis.Size = new System.Drawing.Size(58, 17);
            this.rdodivis.TabIndex = 12;
            this.rdodivis.TabStop = true;
            this.rdodivis.Text = "divisão";
            this.rdodivis.UseVisualStyleBackColor = true;
            this.rdodivis.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // rdomultip
            // 
            this.rdomultip.AutoSize = true;
            this.rdomultip.Location = new System.Drawing.Point(611, 245);
            this.rdomultip.Name = "rdomultip";
            this.rdomultip.Size = new System.Drawing.Size(86, 17);
            this.rdomultip.TabIndex = 13;
            this.rdomultip.TabStop = true;
            this.rdomultip.Text = "multiplicação";
            this.rdomultip.UseVisualStyleBackColor = true;
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(355, 370);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(75, 23);
            this.btnlimpar.TabIndex = 14;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(667, 370);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 15;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // formscalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.rdomultip);
            this.Controls.Add(this.rdodivis);
            this.Controls.Add(this.rdosubt);
            this.Controls.Add(this.rdosoma);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.lblresult);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.lbln1);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.txtn1);
            this.Name = "formscalc";
            this.Text = "calc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.RadioButton rdosoma;
        private System.Windows.Forms.RadioButton rdosubt;
        private System.Windows.Forms.RadioButton rdodivis;
        private System.Windows.Forms.RadioButton rdomultip;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
    }
}

