﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prjmediafor
{
    class Program
    {
        static void Main(string[] args)
        {
            double not1, not2, not3, media, somamedia=0;
            string nome="";
            int numaluno=1;
                Console.WriteLine("Informe o número de alunos");
                numaluno = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= numaluno; i++)
            {
                
              Console.WriteLine("Informe o nome");
              nome=Console.ReadLine();
              Console.WriteLine("Informe a 1° nota");
              not1 = Convert.ToDouble(Console.ReadLine());
              Console.WriteLine("Informe a 2° nota");
              not2 = Convert.ToDouble(Console.ReadLine());
              Console.WriteLine("Informe a 3° nota");
              not3 = Convert.ToDouble(Console.ReadLine());
              media = (not1 + not2 + not3) / 3;
              Console.WriteLine("A media de " + nome + " é " + Math.Round(media, 2)); //Função math arrendonda um valor decimal
                somamedia += media;  
            }
            Console.WriteLine("A media da turma é " + Math.Round(somamedia / numaluno, 2));
            Console.ReadKey();
        }
    }
}
