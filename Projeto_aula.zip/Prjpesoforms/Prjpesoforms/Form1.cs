﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prjpesoforms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnpeso_Click(object sender, EventArgs e)
        {
            double r, a;
            string name;
            name = Convert.ToString(txtname.Text);
            a = Convert.ToDouble(txtaltura.Text);
            if (cmbgenero.Text == "Feminino")
            {
                r = Math.Round((72.7 * a) - 58, 2);
 
                MessageBox.Show(name+", o peso ideial é " + r);
            }
            else if(cmbgenero.Text== "Masculino")
            {
                r = Math.Round((62.7 * a) - 44.7, 2);
                MessageBox.Show(name + ", o peso ideial é " + r);
            }
            else
            {
                
                MessageBox.Show("Escolha uma das opções.");
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtaltura.Clear();
            cmbgenero.Text="";
            txtaltura.Focus();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
