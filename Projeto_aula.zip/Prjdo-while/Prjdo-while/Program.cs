﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prjdo_while
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome, resposta="";
            double n1, n2, n3, med = 0, somamedia = 0, contador = 0;
            do
            {
                contador++;
                if (contador%2==0)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
               
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                Console.Write("Qual o nome do aluno " + contador + ": ");
                nome = Console.ReadLine();
                Console.WriteLine("Qual a 1º nota: ");
                n1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Qual a 2º nota: ");
                n2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Qual a 3º nota: ");
                n3 = Convert.ToDouble(Console.ReadLine());
                med = (n1 + n2 + n3) / 3;
                somamedia = somamedia + med;
                Console.WriteLine("A média do(a) " + nome + " é " + Math.Round(med, 2));
                Console.Write("Deseja continuar(S/N)?");
                resposta = Console.ReadLine();
            } while (resposta=="sim" || resposta=="s" || resposta=="S");
            Console.Write("A média da sala é " + (somamedia / contador)+"(a quantidade de alunos é "+contador+")");
            Console.ReadKey();
        }
    }
}
