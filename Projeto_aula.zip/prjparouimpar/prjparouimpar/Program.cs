﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prjparouimpar
{
    class Program
    {
        static void Main(string[] args)
        {
            double numer, numero;
            Console.Write("Informe um numero: ");
            numer = Convert.ToDouble(Console.ReadLine());
            numero = numer % 2;
            if (numero==0)
            { Console.Write("Esse numero é par"); }
            else
            { Console.Write("Esse numero é impar"); }
            Console.ReadKey();
        }
    }
}
