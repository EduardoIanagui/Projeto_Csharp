﻿namespace Prjlistaaprova
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmedia = new System.Windows.Forms.Button();
            this.lblname = new System.Windows.Forms.Label();
            this.lbln1 = new System.Windows.Forms.Label();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lbln3 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.txtn3 = new System.Windows.Forms.TextBox();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.btnsair = new System.Windows.Forms.Button();
            this.btnlimparlist = new System.Windows.Forms.Button();
            this.lstaprova = new System.Windows.Forms.ListBox();
            this.lstreprova = new System.Windows.Forms.ListBox();
            this.lblaprova = new System.Windows.Forms.Label();
            this.lblreprova = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnmedia
            // 
            this.btnmedia.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmedia.Location = new System.Drawing.Point(40, 385);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(75, 23);
            this.btnmedia.TabIndex = 0;
            this.btnmedia.Text = "Média";
            this.btnmedia.UseVisualStyleBackColor = true;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(37, 71);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(111, 16);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "Informe o nome:";
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln1.Location = new System.Drawing.Point(37, 135);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(106, 16);
            this.lbln1.TabIndex = 2;
            this.lbln1.Text = "Qual a 1º nota:";
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln2.Location = new System.Drawing.Point(37, 199);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(106, 16);
            this.lbln2.TabIndex = 3;
            this.lbln2.Text = "Qual a 2º nota:";
            // 
            // lbln3
            // 
            this.lbln3.AutoSize = true;
            this.lbln3.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln3.Location = new System.Drawing.Point(37, 263);
            this.lbln3.Name = "lbln3";
            this.lbln3.Size = new System.Drawing.Size(106, 16);
            this.lbln3.TabIndex = 4;
            this.lbln3.Text = "Qual a 3º nota:";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(160, 68);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 20);
            this.txtname.TabIndex = 5;
            // 
            // txtn1
            // 
            this.txtn1.Location = new System.Drawing.Point(160, 132);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(100, 20);
            this.txtn1.TabIndex = 6;
            // 
            // txtn3
            // 
            this.txtn3.Location = new System.Drawing.Point(160, 260);
            this.txtn3.Name = "txtn3";
            this.txtn3.Size = new System.Drawing.Size(100, 20);
            this.txtn3.TabIndex = 7;
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(160, 196);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(100, 20);
            this.txtn2.TabIndex = 8;
            // 
            // btnsair
            // 
            this.btnsair.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsair.Location = new System.Drawing.Point(272, 385);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 9;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // btnlimparlist
            // 
            this.btnlimparlist.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimparlist.Location = new System.Drawing.Point(504, 385);
            this.btnlimparlist.Name = "btnlimparlist";
            this.btnlimparlist.Size = new System.Drawing.Size(100, 23);
            this.btnlimparlist.TabIndex = 11;
            this.btnlimparlist.Text = "Limpar lista";
            this.btnlimparlist.UseVisualStyleBackColor = true;
            this.btnlimparlist.Click += new System.EventHandler(this.btnlimparlist_Click);
            // 
            // lstaprova
            // 
            this.lstaprova.FormattingEnabled = true;
            this.lstaprova.Location = new System.Drawing.Point(354, 76);
            this.lstaprova.Name = "lstaprova";
            this.lstaprova.Size = new System.Drawing.Size(164, 277);
            this.lstaprova.TabIndex = 12;
            this.lstaprova.SelectedIndexChanged += new System.EventHandler(this.lstaprova_SelectedIndexChanged);
            // 
            // lstreprova
            // 
            this.lstreprova.FormattingEnabled = true;
            this.lstreprova.Location = new System.Drawing.Point(569, 76);
            this.lstreprova.Name = "lstreprova";
            this.lstreprova.Size = new System.Drawing.Size(164, 277);
            this.lstreprova.TabIndex = 13;
            // 
            // lblaprova
            // 
            this.lblaprova.AutoSize = true;
            this.lblaprova.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaprova.Location = new System.Drawing.Point(372, 46);
            this.lblaprova.Name = "lblaprova";
            this.lblaprova.Size = new System.Drawing.Size(78, 16);
            this.lblaprova.TabIndex = 14;
            this.lblaprova.Text = "Aprovados:";
            // 
            // lblreprova
            // 
            this.lblreprova.AutoSize = true;
            this.lblreprova.Font = new System.Drawing.Font("OpenSymbol", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreprova.Location = new System.Drawing.Point(584, 46);
            this.lblreprova.Name = "lblreprova";
            this.lblreprova.Size = new System.Drawing.Size(87, 16);
            this.lblreprova.TabIndex = 15;
            this.lblreprova.Text = "Reprovados:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblreprova);
            this.Controls.Add(this.lblaprova);
            this.Controls.Add(this.lstreprova);
            this.Controls.Add(this.lstaprova);
            this.Controls.Add(this.btnlimparlist);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.txtn3);
            this.Controls.Add(this.txtn1);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lbln3);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.lbln1);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.btnmedia);
            this.Name = "Form1";
            this.Text = "Lista de aprovados e reporvados";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lbln3;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.TextBox txtn3;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.Button btnlimparlist;
        private System.Windows.Forms.ListBox lstaprova;
        private System.Windows.Forms.ListBox lstreprova;
        private System.Windows.Forms.Label lblaprova;
        private System.Windows.Forms.Label lblreprova;
    }
}

