﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prjlistaaprova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            double n1, n2, n3, r;
            string name;
            n1 = Convert.ToDouble(txtn1.Text);
            n2 = Convert.ToDouble(txtn2.Text);
            n3 = Convert.ToDouble(txtn3.Text);
            name = txtname.Text;
            r= Math.Round((n1 + n2 + n3)/3, 2);
            if (r>=6)
            {
                int cont;
                cont = lstaprova.Items.Count;               
                cont++;
                lstaprova.Items.Add(cont+"- "+name+" nota "+r);
            }
            else
            {
                int cont;
                cont = lstreprova.Items.Count;
                cont++;
                lstreprova.Items.Add(cont+"- "+name + " nota " + r);
            }
            txtname.Clear();
            txtn1.Clear();
            txtn2.Clear();
            txtn3.Clear();
            txtname.Focus();
        }

        private void lstaprova_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimparlist_Click(object sender, EventArgs e)
        {
            lstaprova.Items.Clear();
            lstreprova.Items.Clear();
        }
    }
}
