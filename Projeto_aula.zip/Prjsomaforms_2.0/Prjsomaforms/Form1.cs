﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prjsomaforms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            lblsoma.Text = "";
            txt1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double n1, n2, nr;
            n1 = Convert.ToDouble(txt1.Text);
            n2 = Convert.ToDouble(txt2.Text);
            nr = n1 + n2;
            lblsoma.Text = "A soma é "+nr.ToString();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            double n1, n2, nr;
            n1 = Convert.ToDouble(txt1.Text);
            n2 = Convert.ToDouble(txt2.Text);
            nr = n1 - n2;
            lblsoma.Text = "A subtração é " + nr.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double n1, n2, nr;
            n1 = Convert.ToDouble(txt1.Text);
            n2 = Convert.ToDouble(txt2.Text);
            nr = n1 / n2;
            lblsoma.Text = "A divisão é " + nr.ToString();
        }

        private void btnmultiplicacao_Click(object sender, EventArgs e)
        {
            double n1, n2, nr;
            n1 = Convert.ToDouble(txt1.Text);
            n2 = Convert.ToDouble(txt2.Text);
            nr = n1 / n2;
            lblsoma.Text = "A divisão é " + nr.ToString();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            double n1, n2, nr;
            n1 = Convert.ToDouble(txt1.Text);
            n2 = Convert.ToDouble(txt2.Text);
            nr = n1 * n2;
            lblsoma.Text = "A multiplicação é " + nr.ToString();
        }
    }
}
