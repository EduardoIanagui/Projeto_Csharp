﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prjtabuada
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 0, tabuada = 0;
            Console.WriteLine("Informe um número para ver sua tabuada");
            numero = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i <=10; i++)
            {
                tabuada = numero * i;
                Console.WriteLine(numero+" X "+i+" = "+tabuada);
            }
            Console.ReadKey();
        }
    }
}
