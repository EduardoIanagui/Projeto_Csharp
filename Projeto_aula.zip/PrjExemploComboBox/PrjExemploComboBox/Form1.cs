﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjExemploComboBox
{
    public partial class formcor : Form
    {
        public formcor()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (cmbCores.Text == "Amarelo")
            {
                MessageBox.Show("Vc é uma pessoa avarenta, gosta de dinheiro");
                BackColor.
            }
            else if (cmbCores.Text=="Azul")                
            {
                MessageBox.Show("Vc é uma pessoa tranquila, calma. Vive no azul");
            }
            else if (cmbCores.Text == "Branco")
            {
                MessageBox.Show("Vc é uma pessoa pacifica. Briga e violência não o seu estilo");
            }
            else if (cmbCores.Text == "Preto")
            {
                MessageBox.Show("Vc é uma pessoa triste ou um estilo?");
            }
            else if (cmbCores.Text == "Roxo")
            {
                MessageBox.Show("Vc está sentido poderoso(a)?");
            }
            else if (cmbCores.Text == "Vermelho")
            {
                MessageBox.Show("Vc é uma pessoa paixonada. Tem alguma paixão em mente?");
            }
            else if (cmbCores.Text == "Verde")
            {
                MessageBox.Show("Vc é uma pessoa esperançosa.");
            }
            else
            {
                MessageBox.Show("Escolha uma cor");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
