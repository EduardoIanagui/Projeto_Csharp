﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prexemplotdaplicado
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;  //1 
            double nota1, nota2, media; //2
            Console.WriteLine("Qual o seu nome");  //3
            nome = Console.ReadLine();  //4
            Console.WriteLine("Qual a sua 1º nota (notas de 0 a 100)");
            nota1 = Convert.ToDouble(Console.ReadLine()); //5
            Console.WriteLine("Qual a sua 2º nota (notas de 0 a 100)");
            nota2 = Convert.ToDouble(Console.ReadLine());
            media = (nota1 * 2 + nota2 * 3) / 5; //6 
            Console.WriteLine(nome + ", a media ponderada dessas notas " + media); //7
            if (media >= 50)  //8
            { Console.WriteLine("Você está aprovado, " + nome); }
            else //9
            { Console.WriteLine("Você está reprovado, " + nome); }
            Console.ReadKey(); //10
            /*Explicação dos comandos 
             * Legenda: 
             * 1 é a declaração de variavel do tipo string (voltado para caracteres); 
             * 2 é a declaração de variavel do tipo double (voltado para números reais); 
             * 3 é um comando que uma mensagem especificada é mostrado numa tela, como console; 
             * 4 é um comando que armazena dado, no caso string (numa variavel); 
             * 5 é um comando que converte em double o dado entrado ao qual será armazenado, no caso double; 
             * 6 é uma equação que possibilita o processamento dos dados armazenados e que foi endereçado; 
             * 7 pode ser incluso uma variavel junto ao texto com o +; 
             * 8 e 9 é um comando que diferencia verdade e falso, e executa determinado comando para um e outro, de acordo com a condição; 
             * 9 é caso a condição não seja cumprido; 
             * 10 é um comando que após todo o programa executado, pode ser fechado ao aperta qualquer tecla;*/
             
            /*O programa calcula a media ponderada (de 2 numeros), e diz se foi ou não aprovado. E mostra o nome*/

        }
    }
}
