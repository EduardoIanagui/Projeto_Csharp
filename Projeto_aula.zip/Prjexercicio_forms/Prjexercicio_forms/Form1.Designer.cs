﻿
namespace Prjexercicio_forms
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonvil = new System.Windows.Forms.Button();
            this.buttonsair = new System.Windows.Forms.Button();
            this.buttonlimpar = new System.Windows.Forms.Button();
            this.labeln = new System.Windows.Forms.Label();
            this.labelnc = new System.Windows.Forms.Label();
            this.labelnamec = new System.Windows.Forms.Label();
            this.textBoxn = new System.Windows.Forms.TextBox();
            this.textBoxnc = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonvil
            // 
            this.buttonvil.Location = new System.Drawing.Point(222, 376);
            this.buttonvil.Name = "buttonvil";
            this.buttonvil.Size = new System.Drawing.Size(75, 23);
            this.buttonvil.TabIndex = 0;
            this.buttonvil.Text = "Visualizar";
            this.buttonvil.UseVisualStyleBackColor = true;
            this.buttonvil.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonsair
            // 
            this.buttonsair.Location = new System.Drawing.Point(591, 376);
            this.buttonsair.Name = "buttonsair";
            this.buttonsair.Size = new System.Drawing.Size(75, 23);
            this.buttonsair.TabIndex = 1;
            this.buttonsair.Text = "Sair";
            this.buttonsair.UseVisualStyleBackColor = true;
            this.buttonsair.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonlimpar
            // 
            this.buttonlimpar.Location = new System.Drawing.Point(405, 376);
            this.buttonlimpar.Name = "buttonlimpar";
            this.buttonlimpar.Size = new System.Drawing.Size(75, 23);
            this.buttonlimpar.TabIndex = 2;
            this.buttonlimpar.Text = "Limpar";
            this.buttonlimpar.UseVisualStyleBackColor = true;
            // 
            // labeln
            // 
            this.labeln.AutoSize = true;
            this.labeln.Location = new System.Drawing.Point(64, 94);
            this.labeln.Name = "labeln";
            this.labeln.Size = new System.Drawing.Size(90, 13);
            this.labeln.TabIndex = 3;
            this.labeln.Text = "Qual o seu nome:";
            this.labeln.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelnc
            // 
            this.labelnc.AutoSize = true;
            this.labelnc.Location = new System.Drawing.Point(64, 192);
            this.labelnc.Name = "labelnc";
            this.labelnc.Size = new System.Drawing.Size(116, 13);
            this.labelnc.TabIndex = 4;
            this.labelnc.Text = "Qual o seu sobrenome:";
            // 
            // labelnamec
            // 
            this.labelnamec.AutoSize = true;
            this.labelnamec.Location = new System.Drawing.Point(262, 283);
            this.labelnamec.Name = "labelnamec";
            this.labelnamec.Size = new System.Drawing.Size(35, 13);
            this.labelnamec.TabIndex = 5;
            this.labelnamec.Text = "label3";
            this.labelnamec.Click += new System.EventHandler(this.labelnamec_Click);
            // 
            // textBoxn
            // 
            this.textBoxn.Location = new System.Drawing.Point(252, 94);
            this.textBoxn.Name = "textBoxn";
            this.textBoxn.Size = new System.Drawing.Size(262, 20);
            this.textBoxn.TabIndex = 6;
            this.textBoxn.TextChanged += new System.EventHandler(this.textBoxn_TextChanged);
            // 
            // textBoxnc
            // 
            this.textBoxnc.Location = new System.Drawing.Point(252, 192);
            this.textBoxnc.Name = "textBoxnc";
            this.textBoxnc.Size = new System.Drawing.Size(262, 20);
            this.textBoxnc.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxnc);
            this.Controls.Add(this.textBoxn);
            this.Controls.Add(this.labelnamec);
            this.Controls.Add(this.labelnc);
            this.Controls.Add(this.labeln);
            this.Controls.Add(this.buttonlimpar);
            this.Controls.Add(this.buttonsair);
            this.Controls.Add(this.buttonvil);
            this.Name = "Form1";
            this.Text = "Nome Completo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonvil;
        private System.Windows.Forms.Button buttonsair;
        private System.Windows.Forms.Button buttonlimpar;
        private System.Windows.Forms.Label labeln;
        private System.Windows.Forms.Label labelnc;
        private System.Windows.Forms.Label labelnamec;
        private System.Windows.Forms.TextBox textBoxn;
        private System.Windows.Forms.TextBox textBoxnc;
    }
}

