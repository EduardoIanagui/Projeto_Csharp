﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prjmedia2
{
    class Program
    {
        static void Main(string[] args)
        {
            double n1, n2, n3, media;
            Console.Write("Informe a primeira nota: ");
            n1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Informe a segunda nota: ");
            n2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Informe a terceira nota: ");
            n3 = Convert.ToDouble(Console.ReadLine());
            media = (n1 + n2 + n3) / 3;
            if (media >= 6 && media<10)
            {
                Console.Write("Você está aprovado");
            }
            else if (media == 10)
            {
                Console.Write("Você está aprovado com Distinção");
            }
            else
            {
                Console.Write("Você está Reprovado");
            }
            Console.ReadKey();
        }
    }
}
