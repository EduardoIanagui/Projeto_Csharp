﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mediaforms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtn1.Clear();
            txtn2.Clear();
            txtn3.Clear();
            lblresult.Text = "...";
        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            double n1, n2, n3, r;
            string name;
            name=txtname.Text;
            n1=double.Parse(txtn1.Text);
            n2 = double.Parse(txtn2.Text);
            n3 = double.Parse(txtn3.Text);
            r = Math.Round((n1 + n2 + n3) / 3, 2);
            lblresult.Text = name+ ", sua media é " + r.ToString();
        }
    }
}
