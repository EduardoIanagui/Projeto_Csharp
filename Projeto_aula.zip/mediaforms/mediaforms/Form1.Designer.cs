﻿namespace mediaforms
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmedia = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.lbln1 = new System.Windows.Forms.Label();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lblresult = new System.Windows.Forms.Label();
            this.lbln3 = new System.Windows.Forms.Label();
            this.txtn3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnmedia
            // 
            this.btnmedia.Location = new System.Drawing.Point(67, 360);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(75, 23);
            this.btnmedia.TabIndex = 0;
            this.btnmedia.Text = "Média";
            this.btnmedia.UseVisualStyleBackColor = true;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(357, 360);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(75, 23);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(643, 360);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(75, 23);
            this.btnsair.TabIndex = 2;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(461, 148);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(86, 20);
            this.txtn2.TabIndex = 3;
            // 
            // txtn1
            // 
            this.txtn1.Location = new System.Drawing.Point(461, 101);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(86, 20);
            this.txtn1.TabIndex = 4;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(461, 54);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(86, 20);
            this.txtname.TabIndex = 5;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(275, 61);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(93, 13);
            this.lblname.TabIndex = 6;
            this.lblname.Text = "Insira o seu nome:";
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Location = new System.Drawing.Point(273, 108);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(104, 13);
            this.lbln1.TabIndex = 7;
            this.lbln1.Text = "Qual a primeira nota:";
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Location = new System.Drawing.Point(275, 155);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(109, 13);
            this.lbln2.TabIndex = 8;
            this.lbln2.Text = "Qual a segunda nota:";
            this.lbln2.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblresult.Location = new System.Drawing.Point(375, 288);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(18, 15);
            this.lblresult.TabIndex = 9;
            this.lblresult.Text = "...";
            this.lblresult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbln3
            // 
            this.lbln3.AutoSize = true;
            this.lbln3.Location = new System.Drawing.Point(275, 202);
            this.lbln3.Name = "lbln3";
            this.lbln3.Size = new System.Drawing.Size(103, 13);
            this.lbln3.TabIndex = 11;
            this.lbln3.Text = "Qual a terceira nota:";
            // 
            // txtn3
            // 
            this.txtn3.Location = new System.Drawing.Point(461, 195);
            this.txtn3.Name = "txtn3";
            this.txtn3.Size = new System.Drawing.Size(86, 20);
            this.txtn3.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbln3);
            this.Controls.Add(this.txtn3);
            this.Controls.Add(this.lblresult);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.lbln1);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtn1);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnmedia);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Label lbln3;
        private System.Windows.Forms.TextBox txtn3;
    }
}

