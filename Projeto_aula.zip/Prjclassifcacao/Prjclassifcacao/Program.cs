﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prjclassifcacao
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;
            int anonasc, idade;
            Console.WriteLine("Informe o seu nome");
            nome = Console.ReadLine();
            Console.WriteLine("Informe o seu ano de nascimento");
            anonasc = Convert.ToInt16(Console.ReadLine());
            idade = DateTime.Now.Year - anonasc;
            if (idade>=3 && idade<=5)
            { Console.WriteLine("Sua categoria de natação é infantil 1"); }
            else if (idade>=6 && idade<=11)
            { Console.WriteLine("Sua categoria de natação é infantil 2"); }
            else if (idade >= 12 && idade <= 17)
            { Console.WriteLine("Sua categoria de natação é juvenil"); }
            else if (idade >= 18 && idade <= 59)
            { Console.WriteLine("Sua categoria de natação é adulto"); }
            else if (idade<=2)
            { Console.WriteLine("Você não tem idade adequada para nadar"); }
            else
            { Console.WriteLine("Sua categoria de natação é melhor idade"); }
            Console.ReadKey();
        }
    }
}
